import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from .models import LabTestName_Details
from django.db.models import Max
from django.db.models import Q

@csrf_exempt
@require_http_methods(["POST", "OPTIONS", "GET"])
def Lab_Test_Name_link(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            print(data)

            TestCode = data.get('TestCode', '')
            print("TestCode", TestCode)
            TestName = data.get('TestName', '')
            Amount = data.get('Amount', 0)
            Amount = float(Amount) if Amount else 0
            created_by = data.get('created_by', '')
            location = data.get('location', '')
            Status = data.get('Status')
            if Status:
                 print("Status:", Status)
            else:
                Status = "Active"
                print("Status:", Status)

            if TestCode:
                # if LabTestName_Details.objects.filter(Test_Name=TestName).exists():
                #     return JsonResponse({'warn': f"The TestName is already present in the name of {TestName}"})
                Lab_Test_instance = LabTestName_Details.objects.get(TestCode=TestCode)
                Lab_Test_instance.TestCode = TestCode
                Lab_Test_instance.Test_Name = TestName
                Lab_Test_instance.Prev_Amount = Lab_Test_instance.Amount
                Lab_Test_instance.Amount = Amount
                Lab_Test_instance.Status = Status
                Lab_Test_instance.created_by = created_by
                Lab_Test_instance.location = location
                Lab_Test_instance.save()
                return JsonResponse({'success': 'TestName Updated Successfully'})
            else:
                if LabTestName_Details.objects.filter(Test_Name=TestName).exists():
                    return JsonResponse({'warn': f"The TestName is already present in the name of {TestName}"})
                else:
                    Lab_Test_instance = LabTestName_Details.objects.create(
                        Test_Name=TestName,
                        Prev_Amount=0,
                        Amount=Amount,
                        Status=Status,
                        created_by=created_by,
                        location=location,
                    )
                return JsonResponse({'success': 'TestName Added successfully'})

        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return JsonResponse({'error': 'An internal server error occurred'}, status=500)

    elif request.method == 'GET':
        try:
            TestNames = LabTestName_Details.objects.all()
            TestName_datas = [
                {
                    'id': TestName.TestCode,
                    'Test_Name': TestName.Test_Name,
                    'Prev_Amount': TestName.Prev_Amount,
                    'Amount': TestName.Amount,
                    'Status': TestName.Status,
                    'created_by': TestName.created_by,
                    'location': TestName.location
                } for TestName in TestNames
            ]
            return JsonResponse(TestName_datas, safe=False)

        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return JsonResponse({'error': 'An internal server error occurred'}, status=500)
        


@csrf_exempt
@require_http_methods(["GET"])
def Test_Names_link(request):
    try:
        TestName = request.GET.get("Testgo", None) 
        print("TestName",TestName)# Get the TestName from the query parameters
        if TestName:
            
            TestNames = LabTestName_Details.objects.filter(Status="Active", Test_Name__startswith=TestName)[:10]
            print('TestNames :',TestNames)
        else:
            TestNames = LabTestName_Details.objects.filter(Status="Active")[:10]
        
        testname_data = [
            {
                'id': TestName.TestCode,
                'Test_Name': TestName.Test_Name,
                'Amount': TestName.Amount,
            } for TestName in TestNames
        ]
        
        return JsonResponse(testname_data, safe=False)
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return JsonResponse({'error': 'An internal server error occurred'}, status=500)

from .models import TestName_Favourites, LabTestName_Details



@csrf_exempt
@require_http_methods(["POST", "OPTIONS", "GET"])
def Favourite_TestNames_Details(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            Favourite_Name = data.get('FavouritesName')
            Favourite_Code = data.get('FavouritesCode')
            Test_Names = data.get('FavouriteNamess', [])
            SumOf_Amount = data.get('SumOfAmount')
            Previous_Amount = data.get('Previous_Amount', 0)
            Current_Amount = data.get('Amount', 0)
            created_by = data.get('created_by', '')
            Status = data.get('Status', 'Active')
            
            if Favourite_Code:
                try:
                    Favourite_instance = TestName_Favourites.objects.get(Favourite_Code=Favourite_Code)
                except TestName_Favourites.DoesNotExist:
                    return JsonResponse({'error': 'Favourite with provided code does not exist'}, status=400)
                
                Favourite_instance.Previous_Amount = Favourite_instance.Current_Amount
                Favourite_instance.Current_Amount = float(Current_Amount)
                Favourite_instance.FavouriteName = Favourite_Name
                Favourite_instance.SumOfAmount = SumOf_Amount
                Favourite_instance.created_by = created_by
                Favourite_instance.Status = Status
                Favourite_instance.save()

                Favourite_instance.TestName.clear()
                for test in Test_Names:
                    try:
                        TestName_instance = LabTestName_Details.objects.get(TestCode=test['TestCode'])
                        Favourite_instance.TestName.add(TestName_instance)
                    except LabTestName_Details.DoesNotExist:
                        return JsonResponse({'error': f'TestName with TestCode {test["TestCode"]} does not exist'}, status=400)

                return JsonResponse({'success': 'Favourite Test Names updated successfully'})
            else:
                if not (Favourite_Name and Test_Names and SumOf_Amount is not None):
                    return JsonResponse({'error': 'Missing required fields'}, status=400)

                Favourite_instance = TestName_Favourites(
                    FavouriteName=Favourite_Name,
                    SumOfAmount=SumOf_Amount,
                    Previous_Amount=Previous_Amount,
                    Current_Amount=float(Current_Amount),
                    created_by=created_by,
                    Status=Status
                )
                Favourite_instance.save()

                for test in Test_Names:
                    try:
                        TestName_instance = LabTestName_Details.objects.get(TestCode=test['TestCode'])
                        Favourite_instance.TestName.add(TestName_instance)
                    except LabTestName_Details.DoesNotExist:
                        return JsonResponse({'error': f'TestName with TestCode {test["TestCode"]} does not exist'}, status=400)

                return JsonResponse({'success': 'Favourite Test Names added successfully'})
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return JsonResponse({'error': 'An internal server error occurred'}, status=500)
    elif request.method == 'GET':
        try:
            FavNames = TestName_Favourites.objects.all()
            Register_data = [
                {
                    'id': fav.Favourite_Code,
                    'FavouriteName': fav.FavouriteName,
                    'TestName': [{'TestCode': test.TestCode, 'TestName': test.Test_Name} for test in fav.TestName.all()],
                    'SumOfAmount': fav.SumOfAmount,
                    'Previous_Amount': fav.Previous_Amount,
                    'Current_Amount': fav.Current_Amount,
                    'created_by': fav.created_by,
                    'Status': fav.Status,
                } for fav in FavNames
            ]
            return JsonResponse(Register_data, safe=False)
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return JsonResponse({'error': 'An internal server error occurred'}, status=500)
    return JsonResponse({'error': 'Method not allowed'}, status=405)


@csrf_exempt
@require_http_methods(["GET"])
def Favourites_Names_link(request):
    if request.method == 'GET':
        try:
            FavNames = TestName_Favourites.objects.filter(Status="Active")
            favourite_data = [
                {
                    'id': fav.Favourite_Code,
                    'FavouriteName': fav.FavouriteName,
                    'TestName': [{'TestCode': test.TestCode, 'TestName': test.Test_Name} for test in fav.TestName.all()],
                    'Current_Amount': fav.Current_Amount,
                } for fav in FavNames
            ]
            return JsonResponse(favourite_data, safe=False)
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return JsonResponse({'error': 'An internal server error occurred'}, status=500)
        

    if request.method == 'GET':
        try:
            # Get the first 10 active test names
            TestNames = LabTestName_Details.objects.filter(Status="Active")[:10]
            testname_data = [
                {
                    'id': TestName.TestCode,
                    'Test_Name': TestName.Test_Name,
                    'Amount': TestName.Amount,
                } for TestName in TestNames
            ]
            return JsonResponse(testname_data, safe=False)
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return JsonResponse({'error': 'An internal server error occurred'}, status=500)
        
    
@csrf_exempt
@require_http_methods(["GET"])
def Test_Names_link_LabTest(request):
    try:

       
        TestNames = LabTestName_Details.objects.filter(Status="Active")
        
        testname_data = [
            {
                'id': TestName.TestCode,
                'Test_Name': TestName.Test_Name,
                'Amount': TestName.Amount,
            } for TestName in TestNames
        ]
        
        return JsonResponse(testname_data, safe=False)
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return JsonResponse({'error': 'An internal server error occurred'}, status=500)