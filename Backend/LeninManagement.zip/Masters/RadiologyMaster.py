import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from .models import *
from django.db.models import Sum, Max, Q

import random
import string
from django.db import transaction
from decimal import Decimal

#--------------------------------------------Radiology insert,get,update----------------------------------------







@csrf_exempt
@require_http_methods(["POST", "GET", "OPTIONS"])
def Radiology_Names_link(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            print("Received data:", data)

            RadiologyId = data.get('RadiologyId', '')
            RadiologyName = data.get('RadiologyName', '').strip().upper()
            created_by = data.get('created_by', '')
            Location = data.get('Location', '')
            Statusedit = data.get('Statusedit', False)
            AmountDetails = data.get('AmountArray', [])

            if RadiologyId:
                try:
                    Radiology_instance = RadiologyNames_Details.objects.get(pk=RadiologyId)
                except RadiologyNames_Details.DoesNotExist:
                    return JsonResponse({'warn': 'Radiology ID not found'}, status=404)

                if Statusedit:
                    Radiology_instance.Status = not Radiology_instance.Status
                else:
                    Radiology_instance.Radiology_Name = RadiologyName
                Radiology_instance.save()

                # Clear existing BookingFees_Details for this Radiology instance
                BookingFees_Details.objects.filter(Radiology_Id=Radiology_instance).delete()

                if AmountDetails:
                    booking_fees_list = []
                    # Fetch the last record to calculate the next ID
                    last_record = BookingFees_Details.objects.order_by('-Basic_FeesId').first()
                    if last_record:
                        last_id = last_record.Basic_FeesId
                        next_id = int(last_id[2:]) + 1
                    else:
                        next_id = 1

                    for amount_detail in AmountDetails:
                        from_value = amount_detail.get('From', '')
                        to_value = amount_detail.get('To', '')
                       
                        to_value = to_value if to_value else None
                        amount_value = amount_detail.get('Amount', 0.00)

                        formatted_id = f"BF{next_id:04d}"
                        

                        booking_fees_list.append(
                            BookingFees_Details(
                                Basic_FeesId=formatted_id,
                                Radiology_Id=Radiology_instance,
                                From=from_value,
                                To=to_value,
                                Amount=amount_value,
                                created_by=created_by
                            )
                        )
                        next_id += 1  # Increment the ID for the next entry

                    BookingFees_Details.objects.bulk_create(booking_fees_list)

                return JsonResponse({'success': 'RadiologyName updated successfully'})
            else:
                if not Location:
                    return JsonResponse({'warn': 'Location is required'}, status=400)

                try:
                    Location_instance = Location_Detials.objects.get(Location_Id=Location)
                except Location_Detials.DoesNotExist:
                    return JsonResponse({'warn': 'Invalid location'})

                if RadiologyNames_Details.objects.filter(Radiology_Name=RadiologyName, Location_Name=Location_instance).exists():
                    return JsonResponse({'warn': f"The RadiologyName '{RadiologyName}' is already present in the location '{Location_instance.Location_Name}'"}, status=400)

                Radiology_instance = RadiologyNames_Details(
                    Radiology_Name=RadiologyName,
                    Location_Name=Location_instance,
                    created_by=created_by,
                )
                Radiology_instance.save()

                booking_fees_list = []
                max_id = BookingFees_Details.objects.aggregate(max_id=Max('Basic_FeesId'))['max_id']
                next_id = (int(max_id[2:]) + 1) if max_id else 1

                for amount_detail in AmountDetails:
                    from_value = amount_detail.get('From', 0.00)
                    to_value = amount_detail.get('To', '')
                       
                    to_value = to_value if to_value else None
                    amount_value = amount_detail.get('Amount', 0.00)

                    formatted_id = f"BF{next_id:04d}"

                    booking_fees_list.append(
                        BookingFees_Details(
                            Basic_FeesId=formatted_id,
                            Radiology_Id=Radiology_instance,
                            From=from_value,
                            To=to_value,
                            Amount=amount_value,
                            created_by=created_by
                        )
                    )
                    next_id += 1  # Increment the ID for each entry

                BookingFees_Details.objects.bulk_create(booking_fees_list)
                return JsonResponse({'success': 'RadiologyName added successfully'})

        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return JsonResponse({'error': 'An internal server error occurred'}, status=500)

    elif request.method == 'GET':
        try:
            Radiology_Master = RadiologyNames_Details.objects.all()
            Radiology_Master_data = []
            for Radiology in Radiology_Master:

                booking_fees = BookingFees_Details.objects.filter(Radiology_Id=Radiology).order_by('From')
                booking_fees_data = [
                    {
                        'id': index + 1,
                        'From': booking.From,
                        'To': booking.To if booking.To is not None else f"above {booking.From}",
                        'Amount': booking.Amount
                    }
                    for index, booking in enumerate(booking_fees)
                ]

                Radiology_Master_data.append({
                    'id': Radiology.Radiology_Id,
                    'RadiologyName': Radiology.Radiology_Name,
                    'created_by': Radiology.created_by,
                    'Location_Name': Radiology.Location_Name.Location_Name if Radiology.Location_Name else 'Unknown',
                    'Location_Id': Radiology.Location_Name.pk if Radiology.Location_Name else 'Unknown',
                    'Status': 'Active' if Radiology.Status else 'Inactive',
                    'BookingFees': booking_fees_data
                })

            return JsonResponse(Radiology_Master_data, safe=False)
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return JsonResponse({'error': 'An internal server error occurred'}, status=500)
 

   
#------------------Sub_TestName------------------------
      
        
@csrf_exempt
@require_http_methods(["POST", "OPTIONS", "GET"])
def Radiology_details_link(request):
    if request.method == 'POST':
        try: 
            data = json.loads(request.body)
            print("TestName POST data:", data)

            # Extract data from JSON payload
            TestNameId = data.get('TestNameId', '')
            print("TestNameId",TestNameId)
            TestCode = data.get('TestCode','')
            print('TestCode',TestCode)
            RadiologyName = data.get('RadiologyName', '')
            TestName = data.get('TestName', '')
            Types = data.get('Types', '')
            Amount = data.get('Amount', '')
            print("Amount",Amount)
            Amount = float(Amount) if Amount else 0
            print("Amountaa",Amount)
            created_by = data.get('created_by', '')
            Status = data.get('Status', '')
            SubTestName_list = data.get('SubTestName', [])
            print("SubTestName_list",SubTestName_list)
            
            # Convert RadiologyName to integer if necessary
            RadiologyName = int(RadiologyName)
            rad_instance = RadiologyNames_Details.objects.get(Radiology_Id=RadiologyName)
            
          

            
            if TestCode :
                print('-----')
                # Update existing TestName_Details instance
                with transaction.atomic():
                    test_instance = TestName_Details.objects.get(Test_Code=TestCode)
                  
                    test_instance.Radiology_Id = rad_instance
                    test_instance.Test_Name = TestName
                    test_instance.IsSub_Test = Types
                    test_instance.Prev_Amount = test_instance.Amount
                    test_instance.Amount = Amount
                    test_instance.Status = Status
                    test_instance.save()
                    
                    if len(SubTestName_list) != 0 and Types == 'Yes':

                        for res in SubTestName_list:
                            print(res,'====')
                            subtestcode = res.get('SubTestId')
                            SubTestName = res.get('SubTestName')
                            Amount_s = res.get('Amount', 0)
                            Amount_f = float(Amount_s) if Amount_s else 0
                            Status_ee = res.get('Status')
                            
                            if subtestcode:
                                # Update existing SubTest_Details instance
                                sub_test_inst = SubTest_Details.objects.get(SubTest_Code=subtestcode)
                                sub_test_inst.Test_Code = test_instance
                                sub_test_inst.SubTestName = SubTestName
                                sub_test_inst.Prev_Amount = sub_test_inst.Amount
                                sub_test_inst.Amount = Amount_f
                                sub_test_inst.Status = Status_ee
                                sub_test_inst.save()
                            else:
                                # if TestName_Details.objects.filter(Q(Radiology_Id=rad_instance) & Q(Test_Name=TestName)).exists():
                                    
                                #     return JsonResponse({'warn': f"Same Test Name already exists for Radiology ID {RadiologyName}"})
                                # Create new SubTest_Details instance
                                inst_sub_test_name_instance = SubTest_Details.objects.create(
                                    Test_Code=test_instance,
                                    SubTestName=SubTestName,
                                    Amount=Amount_f,
                                    Status='Active',
                                )
            
            else:
                # Create new TestName_Details instance
                with transaction.atomic():

                    inst_test_name_instance = TestName_Details.objects.create(
                        Radiology_Id=rad_instance,
                        Test_Name=TestName,
                        IsSub_Test=Types,
                        Amount=Amount,
                        Status=Status,
                        created_by=created_by,
                    )
                  

                    
                    if len(SubTestName_list) != 0 and Types == 'Yes':
                        for res in SubTestName_list:
                            SubTestName = res.get('SubTestName')
                            Amount_s = res.get('Amount', 0)
                            Amount_f = float(Amount_s) if Amount_s else 0
                            Status = res.get('Status')
                            
                            inst_sub_test_name_instance = SubTest_Details.objects.create(
                                Test_Code=inst_test_name_instance,
                                SubTestName=SubTestName,
                                Amount=Amount_f,
                                Status=Status,
                            )
                    
                    return JsonResponse({'success': 'TestName Added successfully'})        
        
            return JsonResponse({'success': 'TestName Updated successfully'})
            
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return JsonResponse({'error': 'An internal server error occurred'}, status=500)
    
    elif request.method == 'GET':
        try:
            TestNames = TestName_Details.objects.all()
            TestName_data = []
            
            for idss, TestName in enumerate(TestNames, start=1):
                TestName_dict = {
                    'id': idss,
                    'RadiologyName': TestName.Radiology_Id.Radiology_Name,
                    'locationid': TestName.Radiology_Id.Location_Name.pk,
                    'TestName': TestName.Test_Name,
                    'TestCode': TestName.Test_Code,
                    'Types': TestName.IsSub_Test,
                    'Prev_Amount': TestName.Prev_Amount,
                    'Curr_Amount': TestName.Amount,
                    'Status': TestName.Status,
                    'created_by': TestName.created_by,
                    'Sub_test_data': []
                }
                
                if TestName.IsSub_Test == 'Yes':
                    SubTestNames = SubTest_Details.objects.filter(Test_Code=TestName)
                    for sids, res in enumerate(SubTestNames, start=1):
                        ggg = {
                            'id': sids,
                            'SubTest_Code': res.SubTest_Code,
                            'SubTestName': res.SubTestName,
                            'Prev_Amount': res.Prev_Amount,
                            'Amount': res.Amount,
                            'Status': res.Status
                        }
                        TestName_dict['Sub_test_data'].append(ggg)
                    
                TestName_data.append(TestName_dict)
            
            return JsonResponse(TestName_data, safe=False)
        
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return JsonResponse({'error': 'An internal server error occurred'}, status=500)






@csrf_exempt
@require_http_methods(["OPTIONS", "GET"])        
def Radiology_details_link_view(request):
    try:
        Radiology_Master = RadiologyNames_Details.objects.all()
        
        
        Test_data = []
        index=0
        for rad in Radiology_Master:
                 
            rad_dic={
                'id':index+1,
                'RadiologyId':rad.Radiology_Id,
                'RadiologyName': rad.Radiology_Name,
                'LocationId': rad.Location_Name.pk,
                'TestNames':[]
            }
            TestNames = TestName_Details.objects.filter(Radiology_Id=rad,Status='Active')
            testindx=0
            
            for test in TestNames:
                test_dict={
                    'id':testindx+1,
                    'TestName': test.Test_Name,
                    'TestCode': test.Test_Code,
                    'Types': test.IsSub_Test,
                    'Prev_Amount': test.Prev_Amount,
                    'Curr_Amount': test.Amount,
                    'Sub_test_data': []
                }
                if test.IsSub_Test =="Yes":
                    SubTestNames = SubTest_Details.objects.filter(Test_Code=test.Test_Code,Status='Active')
                    subtestindx = 0
                    
                    for subtest in SubTestNames:
                        subtest_dict={
                            'id':subtestindx+1,
                            'SubTest_Code': subtest.SubTest_Code,
                            'SubTestName': subtest.SubTestName,
                            'Prev_Amount': subtest.Prev_Amount,
                            'Amount': subtest.Amount,
                        }
                        test_dict['Sub_test_data'].append(subtest_dict)
                        subtestindx = subtestindx + 1
                        
                rad_dic['TestNames'].append(test_dict)
                testindx = testindx + 1
                
                
                
            Test_data.append(rad_dic)
            index = index+ 1
        return JsonResponse(Test_data, safe=False)
    
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return JsonResponse({'error': 'An internal server error occurred'}, status=500)







@csrf_exempt
@require_http_methods(["POST", "GET", "OPTIONS"])
def Booking_fees_link(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            print("Received data:", data)
            
            BasicFeesId = data.get('BasicFeesId', '')
            RadiologyName = data.get("RadiologyName", '')
            AmountDetails = data.get("AmountArray", [])
            Created_by = data.get("created_by", '')
            
            # If BasicFeesId is provided, update existing record
            if BasicFeesId:
                try:
                    fess_instance = BookingFees_Details.objects.get(Basic_FeesId=BasicFeesId)
                    
                    for amount_detail in AmountDetails:
                        from_value = float(amount_detail.get('From', 0)) if amount_detail.get('From', '').strip() != '' else 0
                        to_value = float(amount_detail.get('To', 0))if amount_detail.get('To', '').strip() != '' else 0
                        amount_value = float(amount_detail.get('Amount', 0))if amount_detail.get('Amount', '').strip() != '' else 0
                        
                        fess_instance.From = from_value
                        fess_instance.To = to_value
                        fess_instance.Amount = amount_value
                        fess_instance.save()
                    
                    return JsonResponse({'success': 'Booking fees updated successfully'}, status=200)
                
                except BookingFees_Details.DoesNotExist:
                    return JsonResponse({'warn': 'Booking Fees Id not found'}, status=404)
                
            # If BasicFeesId is not provided, handle new record creation
            try:
                rad_instance = RadiologyNames_Details.objects.get(Radiology_Id=RadiologyName)
            except RadiologyNames_Details.DoesNotExist:
                return JsonResponse({'warn': 'Radiology Name not found'}, status=404)
            
            # Fetch the maximum existing Basic_FeesId and generate the next ID
            max_id = BookingFees_Details.objects.aggregate(max_id=Max('Basic_FeesId'))['max_id']
            next_id = (int(max_id) + 1) if max_id else 1
            
            # Prepare a list of BookingFees_Details instances for bulk creation
            booking_fees_list = []
            for amount_detail in AmountDetails:
                # from_value = int(amount_detail.get('From', 0))
                from_value = int(amount_detail.get('From', 0)) if amount_detail.get('From', '').strip() != '' else 0
                to_value = int(amount_detail.get('To', 0)) if amount_detail.get('To', '').strip() != '' else 0
                amount_value = int(amount_detail.get('Amount', 0)) if amount_detail.get('Amount', '').strip() != '' else 0
                
                booking_fees_list.append(
                    BookingFees_Details(
                        Basic_FeesId=str(next_id),  # Assign unique Basic_FeesId
                        Radiology_Id=rad_instance,
                        From=from_value,
                        To=to_value,
                        Amount= amount_value,
                        created_by=Created_by
                    )
                )
                next_id += 1  # Increment the ID for the next record
            
            # Bulk create all the BookingFees_Details instances
            BookingFees_Details.objects.bulk_create(booking_fees_list)
            
            return JsonResponse({'success': 'Booking fees details saved successfully'}, status=200)
        
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return JsonResponse({'error': 'An internal server error occurred'}, status=500)
    
    elif request.method == 'GET':
        try:
            # Fetch all BookingFees_Details instances
            Basicfess = BookingFees_Details.objects.all()
            
            # Prepare the list to store the data
            Basicpay_data = []
            
            # Iterate over the results and build the dictionary
            for idss, Basicpay in enumerate(Basicfess, start=1):
                to_value = "above" if Basicpay.To == Decimal('0.00') else (Basicpay.To)
                from_value = "below" if Basicpay.From == Decimal('0.00') else (Basicpay.From)

                Basicpay_dict = {
                    'id': idss,
                    'RadiologyName': Basicpay.Radiology_Id.Radiology_Name,
                    'From': from_value,
                    'To': to_value,
                    'Amount': Basicpay.Amount
                }
                
                # Append the dictionary to the list
                Basicpay_data.append(Basicpay_dict)
            
            # Return the data as a JSON response
            return JsonResponse(Basicpay_data, safe=False)
        
        except Exception as e:
            print(f"An internal server error occurred: {str(e)}")
            return JsonResponse({'error': 'An internal server error occurred'}, status=500)
    
    return JsonResponse({'warn': 'Invalid request method'}, status=400)


