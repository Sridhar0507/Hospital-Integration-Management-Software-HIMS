from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
import json
from django.http import JsonResponse
from .models import *
from django.utils.timezone import now

@csrf_exempt
@require_http_methods(['POST','GET'])
def Vitals_Form_Details_Link(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            print(data)
            RegistrationId = data.get("RegistrationId")
            temperature = data.get("Temperature")
            pulserate = data.get("PulseRate")
            spo2 = data.get("SPO2")
            heartrate = data.get("HeartRate")
            respiratoryrate = data.get("RespiratoryRate")
            sbp = data.get("SBP")
            dbp = data.get("DBP")
            height = data.get("Height")
            weight = data.get("Weight")
            bmi = data.get("BMI")
            wc = data.get("WC")
            hc = data.get("HC")
            bsl = data.get("BSL")
            Painscore = data.get("Painscore")
            EtCO2 = data.get("ETCO2")
            BreathSounds = data.get("BreathSounds")
            createdby = data.get("Createdby")
            registration_ins=None
            
            if RegistrationId:
                registration_ins = Patient_Appointment_Registration_Detials.objects.get(pk = RegistrationId)
            
            vital_instance = Patient_Vital_Details(
                Registration_Id = registration_ins,
                Temperature = temperature,
                Pulse_Rate =pulserate,
                SPO2 = spo2,
                Heart_Rate = heartrate,
                Respiratory_Rate = respiratoryrate,
                SBP =sbp,
                DBP = dbp,
                Height = height,
                Weight = weight,
                BMI = bmi,
                WC = wc,
                HC = hc,
                BSL = bsl,
                Painscore = Painscore,
                ETCO2 = EtCO2,
                BreathSounds = BreathSounds,
                Created_by = createdby,
            )
            vital_instance.save()
            
            return JsonResponse({'success': 'Vitals saved successfully'})
        except Exception as e:
            print(f"An error occured: {str(e)}")
            return JsonResponse({'error': 'An internal server error occured'}, status = 500)
        
    elif request.method == 'GET':
        try:
            RegistrationId=request.GET.get('RegistrationId')
            if not RegistrationId:
                return JsonResponse({'warn': 'Patient Id required'}, status = 500)
            
            vital_details = Patient_Vital_Details.objects.filter(Registration_Id__pk=RegistrationId)
            print(vital_details,'vital_details')
            vital_details_data =[]
            for idx,vital in enumerate(vital_details, start=1):
                vital_dict = {
                    'id' : idx,
                    'RegistrationId': vital.Registration_Id.pk,
                    'VisitId': vital.Registration_Id.VisitId,
                    'PrimaryDoctorId': vital.Registration_Id.PrimaryDoctor.Doctor_ID,
                    'PrimaryDoctorName': vital.Registration_Id.PrimaryDoctor.ShortName,
                    'Temperature' : vital.Temperature,
                    'PulseRate' : vital.Pulse_Rate,
                    'SPO2' : vital.SPO2,
                    'HeartRate' : vital.Heart_Rate,
                    'RespiratoryRate' : vital.Respiratory_Rate,
                    'SBP' : vital.SBP,
                    'DBP' : vital.DBP,
                    'Height' : vital.Height,
                    'Weight' : vital.Weight,
                    'BMI' : vital.BMI,
                    'WC' : vital.WC,
                    'HC' : vital.HC,
                    'BSL' : vital.BSL,
                    'Painscore' : vital.Painscore,
                    'EtCO2' : vital.ETCO2,
                    'BreathSounds' : vital.BreathSounds,
                    'Date': vital.created_at.strftime('%d-%m-%y'), 
                    'Time' : vital.created_at.strftime('%H:%M:%S'),
                    'Createdby' : vital.Created_by,
                }
                vital_details_data.append(vital_dict)

            return JsonResponse(vital_details_data,safe=False)
        
        except Exception as e:
            print(f"An error occured: {str(e)}")
            return JsonResponse({'error': 'An internal server error occured'}, status = 500)