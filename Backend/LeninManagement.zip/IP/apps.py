from django.apps import AppConfig


class IpConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'IP'
